SIMULADOR DE IMPORTAÇÃO — ARAUTO MANUEL

Projeto Android offline baseado no arquivo index.html do simulador.

Para gerar o APK:
1. Abra este projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build APK(s).
4. O APK será gerado em app/build/outputs/apk/debug/app-debug.apk

O aplicativo carrega o HTML localmente e não precisa de internet para os cálculos.
